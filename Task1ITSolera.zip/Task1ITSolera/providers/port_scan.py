import socket
import nmap

def scan(target_host, common_ports=[21, 22, 23, 25, 53, 80, 110, 139, 443, 445, 3389, 8080]):
    print(f"[*] Scanning common ports for {target_host} using Nmap...")
    open_ports = {}
    try:
        nm = nmap.PortScanner()
        nm.scan(target_host, arguments=f'-p {",".join(map(str, common_ports))} -sV -T4')
        if target_host in nm.all_hosts():
            for proto in nm[target_host].all_protocols():
                if proto == 'tcp':
                    lport = nm[target_host][proto].keys()
                    for port in sorted(lport):
                        state = nm[target_host][proto][port]['state']
                        service = nm[target_host][proto][port]['name']
                        version = nm[target_host][proto][port]['version']
                        if state == 'open':
                            open_ports[port] = f"{service} {version}".strip()
                            print(f"  [+] Port {port} is open ({service} {version})")
        else:
            print(f"  [-] Nmap could not resolve host {target_host} or no results.")
    except nmap.PortScannerError as e:
        print(f"  [-] Nmap error: {e}. Make sure Nmap is installed and in your PATH.")
    except Exception as e:
        print(f"  [-] An unexpected error occurred during port scanning: {e}")
    return open_ports
